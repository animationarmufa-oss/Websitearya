export const KEYS = {
  pakasir: {
    project: "ARMUFA STORE",
    apiKey: "c7ZaITXiSjqYlhMV37bQLnTQslBbAoO2",
    baseUrl: "https://app.pakasir.com/api",
  },

  pterodactyl: {
    domain: "https://hirrxvia.kandigpanel.my.id",
    apiKey: "ptla_pafMSBQVxAZX05k8x1T2WIET5M2j4f8mpAwUmybHqHO",
    clientKey: "ptlc_W9jA9fOM3SQodlZ7Rcw0aPlcl8dAc6ZS43YzQHUfSIR",
    egg: 16,
    nestId: 5,
    locationId: 1,
  },

  digitalocean: {
    apiKey: "",
    region: "sgp1",
    image: "ubuntu-24-04-x64",
  },
};
