export const KEYS = {
  pakasir: {
    project: "armufa-store",
    apiKey: "c7ZaITXiSjqYlhMV37bQLnTQslBbAoO2",
    baseUrl: "https://app.pakasir.com/api",
  },

  pterodactyl: {
    domain: "https://hirrxvia.kandigpanel.my.id",
    apiKey: "ptla_pafMSBQVxAZX05k8x1T2WIET5M2j4f8mpAwUmybHqHO",
    clientKey: "ptlc_W9jA9fOM3SQodlZ7Rcw0aPlcl8dAc6ZS43YzQHUfSIR",
    egg: 16,
    nestId: 5,
    locationId: 1,
  },

  digitalocean: {
    apiKey: "dop_v1_e2ec8cf80480d84d18ba4c646202e01a6059b6390ffeb128975f755b10192ccf",
    region: "sgp1",
    image: "ubuntu-24-04-x64",
  },
};
