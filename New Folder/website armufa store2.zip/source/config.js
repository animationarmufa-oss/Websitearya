// Web HirrOfficial — Client Config (AMAN untuk browser)
// ⚠️ Jangan taruh API KEY di sini. Secrets harus di Vercel Environment Variables.

export const BRAND = {
  name: "ARMUFA STORE",
  tagline: "Powerful hosting • Panel Pterodactyl • Bergaransi",
};

// Mata uang (display only)
export const CURRENCY = "IDR";

// Link (opsional)
export const LINKS = {
  // Jika mau aman, kosongkan dan kembalikan link via endpoint server setelah pembayaran.
  resellerGroupFallback: "", // contoh: "https://chat.whatsapp.com/XXXXX"
};

// Produk & harga (edit bebas)
export const PRODUCTS = [
  {
    key: "panel",
    title: "Panel Pterodactyl",
    subtitle: "Pilih RAM sesuai kebutuhan. Unlimited = request-based.",
    icon: "panel",
    requires: { name: true, hostname: false },
    plans: [
      { key: "panel-1gb", label: "1GB", ramGb: 1, cores: null, price: 1000, badge: "Starter" },
      { key: "panel-2gb", label: "2GB", ramGb: 2, cores: null, price: 2000, badge: "Basic" },
      { key: "panel-3gb", label: "3GB", ramGb: 3, cores: null, price: 3000, badge: "Plus" },
      { key: "panel-4gb", label: "4GB", ramGb: 4, cores: null, price: 4000, badge: "Popular" },
      { key: "panel-5gb", label: "5GB", ramGb: 5, cores: null, price: 5000, badge: "Popular" },
      { key: "panel-6gb", label: "6GB", ramGb: 6, cores: null, price: 6000, badge: "Popular" },
      { key: "panel-7gb", label: "7GB", ramGb: 7, cores: null, price: 6500, badge: "Popular" },
      { key: "panel-8gb", label: "8GB", ramGb: 8, cores: null, price: 7000, badge: "Popular" },
      { key: "panel-9gb", label: "9GB", ramGb: 9, cores: null, price: 8000, badge: "Popular" },
      { key: "panel-10gb", label: "10GB", ramGb: 10, cores: null, price: 10000, badge: "Popular" },
      { key: "panel-11gb", label: "11GB", ramGb: 11, cores: null, price: 11000, badge: "Popular" },
      { key: "panel-12gb", label: "12GB", ramGb: 12, cores: null, price: 12000, badge: "Popular" },
      { key: "panel-13gb", label: "13GB", ramGb: 13, cores: null, price: 13000, badge: "Terlangka" },
      { key: "panel-14gb", label: "14GB", ramGb: 14, cores: null, price: 14000, badge: "Terlaris" },
      { key: "panel-unlimited", label: "UNLIMITED", ramGb: 0, cores: null, price: 15000, badge: "Request" },
    ],
    notes: [
      "Unlimited (ram=0) = request-based (bukan RAM tak terbatas secara fisik).",
      "Resource menyesuaikan kapasitas server & kebijakan fair use.",
    ],
  },

{
    key: "vps",
    title: "VPS DigitalOcean",
    subtitle: "Region Singapore • Ubuntu 24.04 LTS",
    icon: "vps",
    requires: { name: false, hostname: true },
    plans: [
      { key: "vps-1c-2g", label: "1 Core / 2GB", ramGb: 2, cores: 1, price: 10000, badge: "SG" }, // 2g1
      { key: "vps-2c-2g", label: "2 Core / 2GB", ramGb: 2, cores: 2, price: 12000, badge: "SG" }, // 2g2
      { key: "vps-2c-4g", label: "2 Core / 4GB", ramGb: 4, cores: 2, price: 14000, badge: "SG" }, // 4g2
      { key: "vps-4c-8g", label: "4 Core / 8GB", ramGb: 8, cores: 4, price: 17000, badge: "SG" }, // 8g4
      { key: "vps-4c-16g", label: "4 Core / 16GB", ramGb: 16, cores: 4, price: 20000, badge: "SG" }, // 16g4
      { key: "vps-8c-16g", label: "8 Core / 16GB", ramGb: 16, cores: 8, price: 25000, badge: "SG" }, // 16g8
    ],
    notes: [
      "Hostname wajib diisi (contoh: hirr-vps01).",
      "VPS dibuat setelah pembayaran terkonfirmasi.",
    ],
  },
];

// UX defaults
export const UX = {
  autoPollMs: 8000,
};
